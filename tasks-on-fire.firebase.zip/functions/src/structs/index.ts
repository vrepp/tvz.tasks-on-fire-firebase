/**
 * Index for Structs (Interfaces)
 * 
 * @author Valentin Rep
 * @copyright © 2020. All rights reserved.
 * @version 1.0
 */

export { User } from './user'
export { Task } from './task'