/**
 * Task
 * 
 * @author Valentin Rep
 * @copyright © 2020. All rights reserved.
 * @version 1.0
 */
 
export interface Task {
    taskId: string
    title: string
    description: string
}
