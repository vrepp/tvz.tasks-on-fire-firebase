/**
 * User
 * 
 * @author Valentin Rep
 * @copyright © 2020. All rights reserved.
 * @version 1.0
 */
 
export interface User {
    userId: string
    email: string
}
